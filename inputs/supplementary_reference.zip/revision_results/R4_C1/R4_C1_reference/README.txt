R4 C1 | Wang et al. (2016) experimental microstructure validation
Source: W. Wang et al., Materials 2016, 9, 624. https://doi.org/10.3390/ma9080624
Open article: https://pmc.ncbi.nlm.nih.gov/articles/PMC5509042/

EXPERIMENTAL CURVES MUST BE DIGITIZED FROM THE ORIGINAL FIGURES.
Do not use the NNA, modified NNA, or RSE generated-model curves as the experimental reference.

1. Figure 4a: experimental nearest-neighbor surface-gap PDF.
   Export TWO numeric columns from WebPlotDigitizer (x,y), rename as below:
   R4_C1_experimental_NND.csv: distance_um,pdf_per_um
   Follow figure axis actual displayed units (verify PDF axis); if x-axis uses r-normalized units,
   instead use distance_over_mean_radius,pdf_per_dimensionless_distance and adjust MATLAB setting.
   Do NOT compare surface-gap NND with center-distance NND without subtracting 2*r.

2. Figure 7: experimental RDF curve G(h) vs h/r, where h is center distance and
   r=3.05 micrometers mean radius. Export:
   R4_C1_experimental_RDF.csv: h_over_r,G_experimental
   One textual anchor verified: peak at h/r about 2.2. This is NOT a substitute for full points.

3. Figure 5c: experimental Ripley's K short range (optional secondary analysis).
   R4_C1_experimental_K.csv: h_over_r,K_experimental
   K units and edge correction should be checked against paper Eq. 2 before comparing.

Scientific caveats:
- Experimental microstructure roughly 57% fibers, variable radii 2.75-3.25 um.
- VGPP presently uses monodisperse disks r=0.18: spatial arrangement comparison is approximate.
- Experimental SEM image originated from a cited previous paper, not necessarily the same specimen
  supplying the T300/914C elastic data (mechanical example is at 60%).
- Digitized graph points are approximate. Record image resolution, axis calibration and digitization uncertainty.
